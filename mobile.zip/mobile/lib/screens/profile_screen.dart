import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';
import '../services/api_service.dart';
import '../models/models.dart';
import '../widgets/widgets.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  User? _user;
  List<Donghua> _favs = [];
  bool _autoplay = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final u = Supabase.instance.client.auth.currentUser;
    setState(() => _user = u);
    if (u == null) return;
    final c = Supabase.instance.client;
    final r = await c.from('favorites').select('donghua:donghua_id(*)').eq('user_id', u.id);
    _favs = (r as List).map((e) => Donghua.fromJson(e['donghua'])).toList();
    final p = await c.from('profiles').select('autoplay_next').eq('id', u.id).maybeSingle();
    _autoplay = (p?['autoplay_next'] ?? true) as bool;
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('ملفي الشخصي')),
      body: _user == null
        ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('لم تسجّل الدخول.', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => context.push('/auth'), style: FilledButton.styleFrom(backgroundColor: AppTheme.brand), child: const Text('تسجيل الدخول / إنشاء حساب')),
          ]))
        : ListView(padding: const EdgeInsets.all(16), children: [
            Text(_user!.email ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            SwitchListTile(title: const Text('تشغيل الحلقة التالية تلقائيًا'), value: _autoplay, activeColor: AppTheme.brand,
              onChanged: (v) async {
                setState(() => _autoplay = v);
                await Supabase.instance.client.from('profiles').update({'autoplay_next': v}).eq('id', _user!.id);
              }),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: () async { await Supabase.instance.client.auth.signOut(); if (mounted) context.go('/'); },
              icon: const Icon(Icons.logout), label: const Text('تسجيل الخروج')),
            const SizedBox(height: 24),
            const Text('المفضلة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (_favs.isEmpty) const Text('لا توجد مفضلات بعد.', style: TextStyle(color: Colors.grey))
            else Wrap(spacing: 10, runSpacing: 10, children: _favs.map((d) => DonghuaCard(d: d)).toList()),
          ]));
  }
}
