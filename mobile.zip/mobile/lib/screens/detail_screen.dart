import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import '../services/api_service.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class DetailScreen extends StatefulWidget {
  final String slug;
  const DetailScreen({super.key, required this.slug});
  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  Donghua? _d;
  List<({int seasonNumber, String? title, List<Episode> episodes})> _seasons = [];
  bool _fav = false;
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final api = ApiService.instance;
    final d = await api.fetchDonghuaBySlug(widget.slug);
    if (d != null) {
      _seasons = await api.fetchSeasonsWithEpisodes(d.id);
      _fav = await api.isFavorite(d.id);
    }
    setState(() { _d = d; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final d = _d;
    if (d == null) return const Scaffold(body: Center(child: Text('العمل غير موجود.')));
    final firstEp = _seasons.isNotEmpty && _seasons.first.episodes.isNotEmpty ? _seasons.first.episodes.first : null;
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(expandedHeight: 220, pinned: true, flexibleSpace: FlexibleSpaceBar(
          background: d.bannerUrl != null ? CachedNetworkImage(imageUrl: d.bannerUrl!, fit: BoxFit.cover) : Container(color: AppTheme.surfaceLight),
          title: Text(d.titleAr, maxLines: 1),
        )),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ClipRRect(borderRadius: BorderRadius.circular(12), child: SizedBox(width: 100, child: AspectRatio(aspectRatio: 2/3,
              child: d.coverUrl != null ? CachedNetworkImage(imageUrl: d.coverUrl!, fit: BoxFit.cover) : Container(color: Colors.black26)))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.titleAr, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              if (d.titleEn != null) Text(d.titleEn!, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              const SizedBox(height: 6),
              Text('★ ${d.ratingAvg.toStringAsFixed(1)} · ${d.releaseYear ?? '—'} · ${d.animationType.toUpperCase()}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                if (firstEp != null) FilledButton.icon(onPressed: () => context.push('/watch/${firstEp.id}'), icon: const Icon(Icons.play_arrow), label: const Text('ابدأ المشاهدة'), style: FilledButton.styleFrom(backgroundColor: AppTheme.brand)),
                OutlinedButton.icon(onPressed: () async { final f = await ApiService.instance.toggleFavorite(d.id); setState(() => _fav = f); },
                  icon: Icon(_fav ? Icons.favorite : Icons.favorite_border, color: _fav ? Colors.pink : null), label: Text(_fav ? 'في المفضلة' : 'أضف للمفضلة')),
              ]),
            ])),
          ]),
          const SizedBox(height: 16),
          if (d.story != null || d.description != null) Text(d.story ?? d.description!, style: const TextStyle(height: 1.7, color: Colors.grey)),
          const SizedBox(height: 20),
          ..._seasons.map((s) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.title ?? 'الموسم ${s.seasonNumber}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (s.episodes.isEmpty) const Text('لا توجد حلقات منشورة بعد.', style: TextStyle(color: Colors.grey, fontSize: 12)),
            Wrap(spacing: 8, runSpacing: 8, children: s.episodes.map((e) => ActionChip(label: Text('${e.number}'), onPressed: () => context.push('/watch/${e.id}'))).toList()),
            const SizedBox(height: 16),
          ])),
        ]))),
      ]),
    );
  }
}
