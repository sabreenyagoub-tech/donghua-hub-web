import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/models.dart';
import '../widgets/widgets.dart';

class BrowseScreen extends StatefulWidget {
  const BrowseScreen({super.key});
  @override
  State<BrowseScreen> createState() => _BrowseScreenState();
}

class _BrowseScreenState extends State<BrowseScreen> {
  final _ctrl = TextEditingController();
  List<Donghua> _all = [];
  List<Donghua> _filtered = [];
  String _status = '';
  String _anim = '';
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    _all = await ApiService.instance.fetchPublishedDonghua();
    _apply();
    setState(() => _loading = false);
  }

  void _apply() {
    final q = _ctrl.text.trim().toLowerCase();
    setState(() {
      _filtered = _all.where((d) {
        if (_status.isNotEmpty && d.status != _status) return false;
        if (_anim.isNotEmpty && d.animationType != _anim) return false;
        if (q.isEmpty) return true;
        return d.titleAr.toLowerCase().contains(q) ||
            (d.titleEn ?? '').toLowerCase().contains(q) ||
            (d.titleZh ?? '').contains(q);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const TextField(decoration: InputDecoration(hintText: 'ابحث بالاسم العربي/الإنجليزي/الصيني...', border: InputBorder.none, hintStyle: TextStyle(color: Colors.grey))),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(48), child: SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
          _chip('الكل', _status.isEmpty, () => setState(() { _status = ''; _apply(); })),
          _chip('مستمر', _status == 'ongoing', () => setState(() { _status = 'ongoing'; _apply(); })),
          _chip('مكتمل', _status == 'completed', () => setState(() { _status = 'completed'; _apply(); })),
          _chip('قادم', _status == 'upcoming', () => setState(() { _status = 'upcoming'; _apply(); })),
          _chip('2D', _anim == '2d', () => setState(() { _anim = _anim == '2d' ? '' : '2d'; _apply(); })),
          _chip('3D', _anim == '3d', () => setState(() { _anim = _anim == '3d' ? '' : '3d'; _apply(); })),
        ])))),
      body: _loading ? const Center(child: CircularProgressIndicator()) : _filtered.isEmpty
        ? const Center(child: Text('لا توجد نتائج.', style: TextStyle(color: Colors.grey)))
        : GridView.builder(padding: const EdgeInsets.all(12), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: 0.55, crossAxisSpacing: 8, mainAxisSpacing: 8),
            itemCount: _filtered.length, itemBuilder: (_, i) => DonghuaCard(d: _filtered[i])),
    );
  }

  Widget _chip(String label, bool active, VoidCallback onTap) => Padding(padding: const EdgeInsets.only(left: 8, top: 8, bottom: 8),
    child: ChoiceChip(label: Text(label), selected: active, onSelected: (_) => onTap()));
}
