import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:path_provider/path_provider.dart';
import 'package:dio/dio.dart';
import '../services/api_service.dart';
import '../services/download_service.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class WatchScreen extends StatefulWidget {
  final String episodeId;
  const WatchScreen({super.key, required this.episodeId});
  @override
  State<WatchScreen> createState() => _WatchScreenState();
}

class _WatchScreenState extends State<WatchScreen> {
  final _apiBase = const String.fromEnvironment('API_BASE', defaultValue: '');
  Episode? _episode;
  String _donghuaTitle = '';
  String _donghuaSlug = '';
  List<VideoSource> _sources = [];
  List<SubtitleFile> _subs = [];
  List<DownloadSource> _downloads = [];
  List<Episode> _seasonEps = [];
  int _srcIdx = 0;
  String? _activeSubId;
  ChewieController? _chewie;
  VideoPlayerController? _vpc;
  Timer? _saveTimer;
  bool _loading = true;
  String? _error;
  double? _dlProgress;
  String? _dlMsg;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final c = Supabase.instance.client;
      final epRow = await c.from('episodes').select('*, seasons:season_id(*, donghua:donghua_id(title_ar,slug))').eq('id', widget.episodeId).maybeSingle();
      if (epRow == null) { setState(() { _error = 'الحلقة غير موجودة.'; _loading = false; }); return; }
      _episode = Episode.fromJson(epRow);
      final season = epRow['seasons'] as Map<String, dynamic>?;
      _donghuaTitle = season?['donghua']?['title_ar'] ?? '';
      _donghuaSlug = season?['donghua']?['slug'] ?? '';
      final api = ApiService.instance;
      _sources = await api.fetchVideoSources(widget.episodeId);
      _subs = await api.fetchSubtitles(widget.episodeId);
      _downloads = await api.fetchDownloads(widget.episodeId);
      if (season != null) {
        final eps = await c.from('episodes').select().eq('season_id', season['id']).eq('status', 'published').order('episode_number');
        _seasonEps = (eps as List).map((e) => Episode.fromJson(e)).toList();
      }
      final def = _subs.where((s) => s.isDefault).firstOrNull;
      _activeSubId = def?.id;
      if (_sources.isNotEmpty) await _buildPlayer();
      _saveTimer = Timer.periodic(const Duration(seconds: 10), (_) => _savePos());
      if (_apiBase.isNotEmpty) {
        unawaited(Dio().post('$_apiBase/api/views', data: {'episodeId': widget.episodeId}).catchError((_) => null));
      }
    } catch (e) {
      _error = e.toString();
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<File?> _subtitleFile(SubtitleFile sub) async {
    if (_apiBase.isEmpty) return null;
    try {
      final r = await Dio().get('$_apiBase/api/subtitle-url', queryParameters: {'subtitleId': sub.id});
      final signed = r.data['signedUrl'] as String?;
      final fmt = r.data['format'] as String?;
      if (signed == null) return null;
      final txt = await Dio().get(signed, options: Options(responseType: ResponseType.plain));
      var vtt = txt.data.toString();
      if (fmt == 'srt') vtt = _srtToVtt(vtt);
      if (fmt == 'ass' || fmt == 'ssa') return null; // غير مدعوم داخل المشغل
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/sub_${sub.id}.vtt');
      await f.writeAsString(vtt);
      return f;
    } catch (_) { return null; }
  }

  String _srtToVtt(String srt) {
    final lines = srt.replaceAll('\r', '').split('\n');
    final out = <String>['WEBVTT', ''];
    for (final l in lines) {
      if (RegExp(r'^\d+$').hasMatch(l.trim())) continue;
      out.add(l.replaceAllMapped(RegExp(r'(\d{2}:\d{2}:\d{2}),(\d{3})'), (m) => '${m[1]}.${m[2]}'));
    }
    return out.join('\n');
  }

  Future<void> _buildPlayer() async {
    await _vpc?.dispose();
    _chewie?.dispose();
    final src = _sources[_srcIdx];
    ClosedCaptionFile? cap;
    if (_activeSubId != null) {
      final sub = _subs.where((s) => s.id == _activeSubId).firstOrNull;
      if (sub != null) {
        final f = await _subtitleFile(sub);
        if (f != null) cap = FileCaptionFile(await f.readAsString());
      }
    }
    _vpc = VideoPlayerController.networkUrl(Uri.parse(src.url), closedCaptionFile: cap,
      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true));
    await _vpc!.initialize();
    final pos = await ApiService.instance.resumePosition(widget.episodeId);
    if (pos > 5) await _vpc!.seekTo(Duration(seconds: pos));
    _chewie = ChewieController(videoPlayerController: _vpc!, autoInitialize: true, autoPlay: true,
      aspectRatio: 16 / 9, allowedScreenSleep: false,
      additionalOptions: (context) => _sources.asMap().entries.map((e) => OptionItem(onTap: () { setState(() { _srcIdx = e.key; _buildPlayer(); }); }, iconData: Icons.hd, title: e.value.label ?? '${e.value.sourceType} ${e.value.quality}')).toList());
    _vpc!.addListener(() {
      if (_vpc!.value.isCompleted) {
        final idx = _seasonEps.indexWhere((e) => e.id == widget.episodeId);
        final next = idx >= 0 && idx + 1 < _seasonEps.length ? _seasonEps[idx + 1] : null;
        if (next != null && mounted) context.pushReplacement('/watch/${next.id}');
      }
    });
    if (mounted) setState(() {});
  }

  Future<void> _savePos() async {
    final v = _vpc;
    if (v == null || !v.value.isInitialized) return;
    await ApiService.instance.saveWatchPosition(widget.episodeId, v.value.position.inSeconds, v.value.duration.inSeconds);
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _savePos();
    _chewie?.dispose();
    _vpc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_error != null) return Scaffold(body: Center(child: Text(_error!)));
    final src = _sources.isNotEmpty ? _sources[_srcIdx] : null;
    final idx = _seasonEps.indexWhere((e) => e.id == widget.episodeId);
    final prev = idx > 0 ? _seasonEps[idx - 1] : null;
    final next = idx >= 0 && idx + 1 < _seasonEps.length ? _seasonEps[idx + 1] : null;

    return Scaffold(appBar: AppBar(title: Text('$_donghuaTitle — الحلقة ${_episode?.number ?? ''}')),
      body: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
        if (src?.sourceType == 'external_page')
          Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            const Icon(Icons.open_in_new, size: 40, color: Colors.grey),
            const SizedBox(height: 8),
            const Text('هذا المصدر خارجي — افتحه من الرابط المصرح به.', textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: () => launchUrl(Uri.parse(src!.url), mode: LaunchMode.externalApplication), icon: const Icon(Icons.open_in_new), label: const Text('فتح المشغل الخارجي'), style: FilledButton.styleFrom(backgroundColor: AppTheme.brand)),
          ]))
        else if (_chewie != null)
          Chewie(controller: _chewie!)
        else
          const Padding(padding: EdgeInsets.all(24), child: Text('لا يوجد مصدر مشاهدة متاح.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey))),

        if (_sources.length > 1) Padding(padding: const EdgeInsets.all(12), child: Wrap(spacing: 8, children: [
          for (var i = 0; i < _sources.length; i++)
            ChoiceChip(label: Text(_sources[i].label ?? '${_sources[i].sourceType} ${_sources[i].quality}'), selected: _srcIdx == i,
              onSelected: (_) => setState(() { _srcIdx = i; _buildPlayer(); })),
        ])),

        if (_subs.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Wrap(spacing: 8, children: [
          ChoiceChip(label: const Text('بدون ترجمة'), selected: _activeSubId == null, onSelected: (_) => setState(() { _activeSubId = null; _buildPlayer(); })),
          for (final s in _subs) ChoiceChip(label: Text(s.translatorName ?? s.language), selected: _activeSubId == s.id,
            onSelected: (_) => setState(() { _activeSubId = s.id; _buildPlayer(); })),
        ])),

        Padding(padding: const EdgeInsets.all(12), child: Row(children: [
          if (prev != null) Expanded(child: OutlinedButton(onPressed: () => context.pushReplacement('/watch/${prev.id}'), child: const Text('← السابقة'))),
          if (prev != null && next != null) const SizedBox(width: 8),
          if (next != null) Expanded(child: FilledButton(onPressed: () => context.pushReplacement('/watch/${next.id}'), style: FilledButton.styleFrom(backgroundColor: AppTheme.brand), child: const Text('التالية →'))),
        ])),

        if (_downloads.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('التنزيل المصرح به', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          for (final d in _downloads) Card(child: ListTile(
            leading: const Icon(Icons.download),
            title: Text('${d.quality}${d.fileSizeBytes != null ? ' · ${(d.fileSizeBytes! / 1048576).toStringAsFixed(1)} MB' : ''}'),
            trailing: _dlProgress != null ? SizedBox(width: 80, child: LinearProgressIndicator(value: _dlProgress)) : null,
            onTap: () async {
              try {
                final task = await DownloadService.start(d.url, '${_donghuaSlug}_ep${_episode?.number}_${d.quality}.mp4');
                task.progress.listen((p) => setState(() => _dlProgress = p), onDone: () => setState(() { _dlProgress = null; _dlMsg = 'اكتمل التنزيل.'; }), onError: (e) => setState(() { _dlProgress = null; _dlMsg = 'فشل التنزيل: $e'; }));
              } catch (e) { setState(() => _dlMsg = e.toString()); }
            },
          )),
          if (_dlMsg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_dlMsg!, style: const TextStyle(fontSize: 12, color: Colors.amber))),
        ])),

        if (_seasonEps.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('حلقات الموسم', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: _seasonEps.map((e) => ActionChip(label: Text('${e.number}'), selected: e.id == widget.episodeId,
            onPressed: () => context.pushReplacement('/watch/${e.id}'))).toList()),
        ])),
      ]));
  }
}
