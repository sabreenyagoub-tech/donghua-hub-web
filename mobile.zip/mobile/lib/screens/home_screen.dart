import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../services/api_service.dart';
import '../models/models.dart';
import '../widgets/widgets.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<_HomeData> _future;

  @override
  void initState() { super.initState(); _future = _load(); }

  Future<_HomeData> _load() async {
    final api = ApiService.instance;
    final donghua = await api.fetchPublishedDonghua();
    final latest = await api.fetchLatestEpisodes();
    return _HomeData(donghua, latest);
  }

  List<Donghua> _byGenre(List<Donghua> all, String slug) => all.where((d) => d.genres.contains(slug)).take(12).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Donghua Hub'), actions: [
        IconButton(icon: const Icon(Icons.search), onPressed: () => context.push('/browse')),
        IconButton(icon: const Icon(Icons.person), onPressed: () => context.push('/profile')),
      ]),
      body: FutureBuilder<_HomeData>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snap.hasError) return Center(child: Text('تعذّر التحميل: ${snap.error}\nتحقق من اتصالك.', textAlign: TextAlign.center));
          final data = snap.data!;
          final all = data.donghua;
          if (all.isEmpty) return const Center(child: Text('لا توجد أعمال منشورة بعد.', style: TextStyle(color: Colors.grey)));
          final featured = all.where((d) => d.isFeatured).toList();
          final hero = featured.isNotEmpty ? featured.first : all.first;
          final latestEps = data.latestEpisodes;
          return RefreshIndicator(
            onRefresh: () async => setState(() => _future = _load()),
            child: ListView(children: [
              _Hero(d: hero),
              if (latestEps.isNotEmpty) _LatestEpisodesRow(items: latestEps),
              SectionRow(title: 'الأكثر مشاهدة', items: [...all]..sort((a, b) => b.viewCount.compareTo(a.viewCount))..take(12).toList()),
              SectionRow(title: 'الأعلى تقييمًا', items: [...all]..sort((a, b) => b.ratingAvg.compareTo(a.ratingAvg))..take(12).toList()),
              SectionRow(title: 'مستمرة حاليًا', items: all.where((d) => d.status == 'ongoing').take(12).toList()),
              SectionRow(title: 'أحدث الأعمال', items: all.take(12).toList()),
              SectionRow(title: 'اختيارات المحرر', items: all.where((d) => d.editorPick).take(12).toList()),
              SectionRow(title: 'أكشن وقتال', items: _byGenre(all, 'action')),
              SectionRow(title: 'فانتازيا وسحر', items: _byGenre(all, 'fantasy')),
              SectionRow(title: 'زراعة القوة الروحية', items: _byGenre(all, 'cultivation')),
              SectionRow(title: 'فنون قتالية', items: _byGenre(all, 'martial-arts')),
              SectionRow(title: 'مغامرات', items: _byGenre(all, 'adventure')),
              SectionRow(title: 'تناسخ وعالم آخر', items: _byGenre(all, 'isekai')),
              SectionRow(title: 'أعمال 3D', items: _byGenre(all, '3d')),
              SectionRow(title: 'أعمال 2D', items: _byGenre(all, '2d')),
              const SizedBox(height: 24),
            ]),
          );
        },
      ),
    );
  }
}

class _HomeData { final List<Donghua> donghua; final List<Map<String, dynamic>> latestEpisodes; _HomeData(this.donghua, this.latestEpisodes); }

class _Hero extends StatelessWidget {
  final Donghua d;
  const _Hero({required this.d});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: () => context.push('/donghua/${d.slug}'),
      child: Container(margin: const EdgeInsets.all(12), height: 200, decoration: BoxDecoration(borderRadius: BorderRadius.circular(16),
        image: d.bannerUrl != null ? DecorationImage(image: NetworkImage(d.bannerUrl!), fit: BoxFit.cover) : null, color: AppTheme.surfaceLight),
        child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: const LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])),
          padding: const EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: AppTheme.brand, borderRadius: BorderRadius.circular(6)), child: const Text('عمل مميز', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
            const SizedBox(height: 8),
            Text(d.titleAr, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            if (d.titleEn != null) Text(d.titleEn!, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]))));
  }
}

class _LatestEpisodesRow extends StatelessWidget {
  final List<Map<String, dynamic>> items;
  const _LatestEpisodesRow({required this.items});
  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.only(top: 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Text('أحدث الحلقات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
      const SizedBox(height: 10),
      SizedBox(height: 130, child: ListView.separated(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: items.length > 20 ? 20 : items.length, separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) {
          final e = items[i];
          final dh = (e['seasons'] as Map?)?['donghua'] as Map<String, dynamic>?;
          if (dh == null) return const SizedBox.shrink();
          return EpisodeCard(
            title: dh['title_ar'] ?? '',
            episodeNumber: e['episode_number'] ?? 0,
            coverUrl: dh['cover_image_url'],
            onTap: () => context.push('/watch/${e['id']}'),
          );
        })),
    ]));
  }
}
