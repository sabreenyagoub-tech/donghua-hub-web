import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _name = TextEditingController();
  bool _login = true;
  bool _busy = false;
  String? _msg;

  Future<void> _submit() async {
    setState(() { _busy = true; _msg = null; });
    try {
      final c = Supabase.instance.client;
      if (_login) {
        await c.auth.signInWithPassword(email: _email.text.trim(), password: _pass.text);
      } else {
        await c.auth.signUp(email: _email.text.trim(), password: _pass.text, data: {'display_name': _name.text.trim()});
        _msg = 'تم إنشاء الحساب. تحقق من بريدك إن كان التأكيد مطلوبًا.';
      }
      if (mounted && _login) context.go('/profile');
    } catch (e) {
      _msg = e.toString();
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(_login ? 'تسجيل الدخول' : 'إنشاء حساب')),
      body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        if (!_login) TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم الظاهر')),
        const SizedBox(height: 12),
        TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
        const SizedBox(height: 12),
        TextField(controller: _pass, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور (6 أحرف على الأقل)')),
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: _busy ? null : _submit, style: FilledButton.styleFrom(backgroundColor: AppTheme.brand, padding: const EdgeInsets.symmetric(vertical: 14)),
          child: Text(_busy ? 'جارٍ التنفيذ...' : (_login ? 'دخول' : 'إنشاء الحساب')))),
        TextButton(onPressed: () => setState(() => _login = !_login), child: Text(_login ? 'ليس لديك حساب؟ سجّل الآن' : 'لديك حساب؟ سجّل الدخول')),
        if (_msg != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_msg!, style: const TextStyle(color: Colors.amber), textAlign: TextAlign.center)),
        const Spacer(),
        const Text('يمكنك تصفح الأعمال ومشاهدتها دون حساب.', style: TextStyle(color: Colors.grey, fontSize: 12), textAlign: TextAlign.center),
      ])));
  }
}
