import 'package:flutter/material.dart';

class AppTheme {
  static const Color brand = Color(0xFFE11D48);
  static const Color accent = Color(0xFFF59E0B);
  static const Color bg = Color(0xFF0B0D12);
  static const Color surface = Color(0xFF161A23);
  static const Color surfaceLight = Color(0xFF1F2430);

  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(
        primary: brand,
        secondary: accent,
        surface: surface,
      ),
      fontFamily: 'Tajawal',
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF07080C),
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardTheme(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF10131A),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      ),
    );
  }
}
