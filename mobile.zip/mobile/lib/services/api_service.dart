import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/models.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// طبقة البيانات الوحيدة — تتحدث مباشرة إلى Supabase (RLS يفرض الأمان).
class ApiService {
  static final ApiService _i = ApiService._();
  static ApiService get instance => _i;
  ApiService._();

  SupabaseClient get _db => Supabase.instance.client;
  String get apiBase => const String.fromEnvironment('API_BASE', defaultValue: ''); // موقع Next.js للـ API المساعد

  Future<AppSettings> fetchSettings() async {
    final r = await _db.from('app_settings').select().eq('id', 1).maybeSingle();
    return AppSettings.fromJson((r as Map<String, dynamic>?) ?? {});
  }

  Future<List<Donghua>> fetchPublishedDonghua({int limit = 500}) async {
    final r = await _db.from('donghua')
      .select('*, genres:donghua_genres(genres(slug))')
      .eq('is_published', true).eq('copyright_hold', false)
      .order('added_at', ascending: false).limit(limit);
    return (r as List).map((e) => Donghua.fromJson(e)).toList();
  }

  Future<List<Map<String, dynamic>>> fetchLatestEpisodes({int limit = 30}) async {
    final r = await _db.from('episodes')
      .select('*, seasons:season_id(donghua:donghua_id(*))')
      .eq('status', 'published').order('published_at', ascending: false).limit(limit);
    return List<Map<String, dynamic>>.from(r as List);
  }

  Future<Donghua?> fetchDonghuaBySlug(String slug) async {
    final r = await _db.from('donghua').select('*, genres:donghua_genres(genres(slug))').eq('slug', slug).maybeSingle();
    if (r == null) return null;
    return Donghua.fromJson(r);
  }

  Future<List<({int seasonNumber, String? title, List<Episode> episodes})>> fetchSeasonsWithEpisodes(String donghuaId) async {
    final r = await _db.from('seasons').select('*, episodes(*)').eq('donghua_id', donghuaId).eq('is_hidden', false).order('sort_order');
    final out = <({int seasonNumber, String? title, List<Episode> episodes})>[];
    for (final s in (r as List)) {
      final eps = ((s['episodes'] as List?) ?? []).map((e) => Episode.fromJson(e)).where((e) => e.status == 'published').toList()
        ..sort((a, b) => a.number.compareTo(b.number));
      out.add((seasonNumber: s['season_number'] ?? 1, title: s['title_ar'], episodes: eps));
    }
    out.sort((a, b) => a.seasonNumber.compareTo(b.seasonNumber));
    return out;
  }

  Future<Episode?> fetchEpisode(String id) async {
    final r = await _db.from('episodes').select().eq('id', id).maybeSingle();
    return r == null ? null : Episode.fromJson(r);
  }

  Future<List<VideoSource>> fetchVideoSources(String episodeId) async {
    final r = await _db.from('video_sources').select().eq('episode_id', episodeId).eq('is_active', true).order('sort_order');
    return (r as List).map((e) => VideoSource.fromJson(e)).toList();
  }

  Future<List<DownloadSource>> fetchDownloads(String episodeId) async {
    final r = await _db.from('download_sources').select().eq('episode_id', episodeId).eq('is_active', true);
    return (r as List).map((e) => DownloadSource.fromJson(e)).toList();
  }

  Future<List<SubtitleFile>> fetchSubtitles(String episodeId) async {
    final r = await _db.from('subtitle_files').select().eq('episode_id', episodeId).eq('status', 'available').order('is_default', ascending: false);
    return (r as List).map((e) => SubtitleFile.fromJson(e)).toList();
  }

  /// رابط الترجمة الموقّع (عبر الـ API المساعد في Next.js)
  Future<String?> signedSubtitleUrl(String subtitleId) async {
    if (apiBase.isEmpty) return null;
    try {
      // ignore: avoid_dynamic_calls
      final r = await (await _db.auth.getSession()).session == null ? null : null;
      // استدعاء HTTP بسيط
      // (في التنفيذ الكامل: استخدم Dio للاتصال بـ $apiBase/api/subtitle-url?subtitleId=...)
      return null;
    } catch (_) { return null; }
  }

  Future<void> saveWatchPosition(String episodeId, int position, int duration) async {
    final user = _db.auth.currentUser;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('pos_$episodeId', position);
    if (user != null) {
      await _db.from('watch_history').upsert({
        'user_id': user.id, 'episode_id': episodeId, 'position_seconds': position,
        'duration_seconds': duration, 'last_watched_at': DateTime.now().toIso8601String(),
      }, onConflict: 'user_id,episode_id');
    }
  }

  Future<int> resumePosition(String episodeId) async {
    final prefs = await SharedPreferences.getInstance();
    var pos = prefs.getInt('pos_$episodeId') ?? 0;
    final user = _db.auth.currentUser;
    if (user != null) {
      final r = await _db.from('watch_history').select('position_seconds').eq('episode_id', episodeId).maybeSingle();
      if (r != null && (r['position_seconds'] ?? 0) > pos) pos = r['position_seconds'];
    }
    return pos;
  }

  Future<bool> toggleFavorite(String donghuaId) async {
    final user = _db.auth.currentUser;
    if (user == null) return false;
    final existing = await _db.from('favorites').select().eq('user_id', user.id).eq('donghua_id', donghuaId).maybeSingle();
    if (existing != null) { await _db.from('favorites').delete().eq('user_id', user.id).eq('donghua_id', donghuaId); return false; }
    await _db.from('favorites').insert({'user_id': user.id, 'donghua_id': donghuaId});
    return true;
  }

  Future<bool> isFavorite(String donghuaId) async {
    final user = _db.auth.currentUser;
    if (user == null) return false;
    final r = await _db.from('favorites').select().eq('user_id', user.id).eq('donghua_id', donghuaId).maybeSingle();
    return r != null;
  }
}
