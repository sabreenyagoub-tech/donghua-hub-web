import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class DownloadTask {
  final Stream<double> progress; // 0.0 .. 1.0
  final Future<String> result;   // مسار الملف عند النجاح
  final void Function() cancel;
  DownloadTask({required this.progress, required this.result, required this.cancel});
}

class DownloadService {
  static final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(minutes: 30),
  ));

  static Future<DownloadTask> start(String url, String fileName) async {
    if (Platform.isAndroid) {
      final s = await Permission.storage.request();
      if (!s.isGranted) {
        final photos = await Permission.photos.request();
        if (!photos.isGranted) throw 'لم تُمنح صلاحية الوصول إلى التخزين.';
      }
    }
    final dir = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    final savePath = '${dir.path}/DonghuaHub/$fileName';
    await Directory('${dir.path}/DonghuaHub').create(recursive: true);

    final controller = StreamController<double>.broadcast();
    final cancelToken = CancelToken();
    final completer = Completer<String>();

    _dio.download(url, savePath, cancelToken: cancelToken, onReceiveProgress: (rec, total) {
      if (total > 0) controller.add(rec / total);
    }).then((_) {
      controller.add(1.0);
      controller.close();
      if (!completer.isCompleted) completer.complete(savePath);
    }).catchError((e) {
      controller.addError(e);
      controller.close();
      if (!completer.isCompleted) completer.completeError(e);
    });

    return DownloadTask(
      progress: controller.stream,
      result: completer.future,
      cancel: () => cancelToken.cancel('user_cancelled'),
    );
  }
}
