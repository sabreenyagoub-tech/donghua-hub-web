/// نماذج البيانات — تطابق مخطط Supabase
class Donghua {
  final String id, slug, titleAr;
  final String? titleEn, titleZh, description, story, coverUrl, bannerUrl, studio;
  final int? releaseYear, totalEpisodes, seasonsCount, episodeDurationMin;
  final int currentEpisode, viewCount, ratingCount;
  final double ratingAvg;
  final String status, animationType;
  final bool isFeatured, editorPick, isPublished;
  final List<String> genres;

  Donghua({
    required this.id, required this.slug, required this.titleAr,
    this.titleEn, this.titleZh, this.description, this.story,
    this.coverUrl, this.bannerUrl, this.studio,
    this.releaseYear, this.totalEpisodes, this.seasonsCount, this.episodeDurationMin,
    this.currentEpisode = 0, this.viewCount = 0, this.ratingCount = 0, this.ratingAvg = 0,
    this.status = 'ongoing', this.animationType = '2d',
    this.isFeatured = false, this.editorPick = false, this.isPublished = true,
    this.genres = const [],
  });

  factory Donghua.fromJson(Map<String, dynamic> j) {
    final g = (j['genres'] as List?) ?? [];
    return Donghua(
      id: j['id'], slug: j['slug'], titleAr: j['title_ar'] ?? '',
      titleEn: j['title_en'], titleZh: j['title_zh'],
      description: j['description'], story: j['story'],
      coverUrl: j['cover_image_url'], bannerUrl: j['banner_image_url'],
      studio: j['studio'],
      releaseYear: j['release_year'], totalEpisodes: j['total_episodes'],
      seasonsCount: j['seasons_count'], episodeDurationMin: j['episode_duration_min'],
      currentEpisode: j['current_episode'] ?? 0,
      viewCount: j['view_count'] ?? 0,
      ratingCount: j['rating_count'] ?? 0,
      ratingAvg: (j['rating_avg'] ?? 0).toDouble(),
      status: j['status'] ?? 'ongoing',
      animationType: j['animation_type'] ?? '2d',
      isFeatured: j['is_featured'] ?? false,
      editorPick: j['editor_pick'] ?? false,
      isPublished: j['is_published'] ?? true,
      genres: g.map((e) => (e as Map)['genres']?['slug']?.toString() ?? '').where((s) => s.isNotEmpty).toList(),
    );
  }
}

class Episode {
  final String id, seasonId;
  final int number;
  final String? title, description;
  final String? airDate;
  final int? durationSeconds;
  final String status;
  final int viewCount;
  Episode({required this.id, required this.seasonId, required this.number, this.title, this.description, this.airDate, this.durationSeconds, this.status = 'published', this.viewCount = 0});
  factory Episode.fromJson(Map<String, dynamic> j) => Episode(
    id: j['id'], seasonId: j['season_id'], number: j['episode_number'] ?? 0,
    title: j['title_ar'], description: j['description'], airDate: j['air_date'],
    durationSeconds: j['duration_seconds'], status: j['status'] ?? 'published',
    viewCount: j['view_count'] ?? 0,
  );
}

class VideoSource {
  final String id, url, sourceType, quality, language;
  final String? label;
  VideoSource({required this.id, required this.url, required this.sourceType, required this.quality, required this.language, this.label});
  factory VideoSource.fromJson(Map<String, dynamic> j) => VideoSource(
    id: j['id'], url: j['url'], sourceType: j['source_type'], quality: j['quality'] ?? 'auto', language: j['language'] ?? 'ar', label: j['label']);
}

class DownloadSource {
  final String id, url, quality;
  final int? fileSizeBytes;
  DownloadSource({required this.id, required this.url, required this.quality, this.fileSizeBytes});
  factory DownloadSource.fromJson(Map<String, dynamic> j) => DownloadSource(id: j['id'], url: j['url'], quality: j['quality'] ?? '720p', fileSizeBytes: j['file_size_bytes']);
}

class SubtitleFile {
  final String id, storagePath, format, language;
  final String? translatorName;
  final bool isDefault;
  SubtitleFile({required this.id, required this.storagePath, required this.format, required this.language, this.translatorName, this.isDefault = false});
  factory SubtitleFile.fromJson(Map<String, dynamic> j) => SubtitleFile(
    id: j['id'], storagePath: j['storage_path'], format: j['format'], language: j['language'] ?? 'ar',
    translatorName: j['translator_name'], isDefault: j['is_default'] ?? false);
}

class AppSettings {
  final String siteName, primaryColor, accentColor, bgColor;
  AppSettings({this.siteName = 'Donghua Hub', this.primaryColor = '#E11D48', this.accentColor = '#F59E0B', this.bgColor = '#0B0D12'});
  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
    siteName: j['site_name'] ?? 'Donghua Hub',
    primaryColor: j['primary_color'] ?? '#E11D48',
    accentColor: j['accent_color'] ?? '#F59E0B',
    bgColor: j['background_color'] ?? '#0B0D12');
}
