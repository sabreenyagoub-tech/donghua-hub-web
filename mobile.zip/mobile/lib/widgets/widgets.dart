import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import '../models/models.dart';

class DonghuaCard extends StatelessWidget {
  final Donghua d;
  const DonghuaCard({super.key, required this.d});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/donghua/${d.slug}'),
      child: SizedBox(width: 130, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ClipRRect(borderRadius: BorderRadius.circular(12), child: AspectRatio(aspectRatio: 2/3,
          child: d.coverUrl != null
            ? CachedNetworkImage(imageUrl: d.coverUrl!, fit: BoxFit.cover, placeholder: (_, __) => Container(color: Colors.black26))
            : Container(color: Colors.black26, child: const Center(child: Text('لا صورة', style: TextStyle(fontSize: 10)))),
        )),
        const SizedBox(height: 6),
        Text(d.titleAr, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
        Text('★ ${d.ratingAvg.toStringAsFixed(1)} · ${d.currentEpisode > 0 ? '${d.currentEpisode} حلقة' : ''}', style: const TextStyle(fontSize: 10, color: Colors.grey)),
      ])),
    );
  }
}

class SectionRow extends StatelessWidget {
  final String title;
  final List<Donghua> items;
  const SectionRow({super.key, required this.title, required this.items});
  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return Padding(padding: const EdgeInsets.only(top: 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(children: [
        Container(width: 4, height: 18, decoration: BoxDecoration(color: AppTheme.brand, borderRadius: BorderRadius.circular(4))),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ])),
      const SizedBox(height: 10),
      SizedBox(height: 210, child: ListView.separated(
        scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) => DonghuaCard(d: items[i]),
      )),
    ]));
  }
}

class EpisodeCard extends StatelessWidget {
  final String title;
  final int episodeNumber;
  final String? coverUrl;
  final VoidCallback onTap;
  const EpisodeCard({super.key, required this.title, required this.episodeNumber, this.coverUrl, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onTap, child: SizedBox(width: 160, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      ClipRRect(borderRadius: BorderRadius.circular(10), child: AspectRatio(aspectRatio: 16/9,
        child: coverUrl != null ? CachedNetworkImage(imageUrl: coverUrl!, fit: BoxFit.cover) : Container(color: Colors.black26))),
      const SizedBox(height: 6),
      Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
      Text('الحلقة $episodeNumber', style: const TextStyle(fontSize: 10, color: Colors.grey)),
    ])));
  }
}
