import { redirect } from 'next/navigation';
export default function AdminLogin() { redirect('/auth/login?next=/admin'); }
